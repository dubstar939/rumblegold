(() => {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const rnd = (a, b) => a + Math.random() * (b - a);
  const MB = () => window.mindblown;

  const MOVES = {
    grizzly: {
      quick:    { windup: .07, active: .12, recover: .17, range: 206, damage: 8,  hitstun: .36, knockback: 26, gain: 11, cooldown: .14, lunge: 14 },
      power:    { windup: .18, active: .15, recover: .32, range: 272, damage: 17, hitstun: .60, knockback: 50, gain: 17, cooldown: .30, lunge: 24 },
      kick:     { windup: .20, active: .14, recover: .33, range: 238, damage: 14, hitstun: .56, knockback: 54, gain: 15, cooldown: .32, lunge: 22 },
      finisher: { windup: .24, active: .20, recover: .46, range: 326, damage: 34, hitstun: .84, knockback: 82, gain: 0,  cooldown: .52, lunge: 32 }
    },
    crown: {
      quick:    { windup: .055, active: .11, recover: .14, range: 214, damage: 6,  hitstun: .30, knockback: 20, gain: 10, cooldown: .11, lunge: 12 },
      power:    { windup: .14, active: .14, recover: .28, range: 260, damage: 13, hitstun: .54, knockback: 42, gain: 16, cooldown: .26, lunge: 20 },
      kick:     { windup: .16, active: .13, recover: .30, range: 246, damage: 12, hitstun: .48, knockback: 52, gain: 14, cooldown: .28, lunge: 22 },
      finisher: { windup: .21, active: .19, recover: .42, range: 318, damage: 29, hitstun: .78, knockback: 72, gain: 0,  cooldown: .48, lunge: 28 }
    },
    junkyard: {
      quick:    { windup: .08, active: .12, recover: .18, range: 204, damage: 8,  hitstun: .36, knockback: 28, gain: 11, cooldown: .15, lunge: 14 },
      power:    { windup: .19, active: .16, recover: .34, range: 274, damage: 18, hitstun: .62, knockback: 54, gain: 17, cooldown: .32, lunge: 26 },
      kick:     { windup: .19, active: .14, recover: .32, range: 232, damage: 13, hitstun: .54, knockback: 50, gain: 14, cooldown: .31, lunge: 20 },
      finisher: { windup: .25, active: .20, recover: .48, range: 330, damage: 36, hitstun: .86, knockback: 86, gain: 0,  cooldown: .54, lunge: 34 }
    },
    midnight: {
      quick:    { windup: .05, active: .10, recover: .13, range: 220, damage: 6,  hitstun: .28, knockback: 18, gain: 10, cooldown: .10, lunge: 16 },
      power:    { windup: .13, active: .13, recover: .26, range: 252, damage: 13, hitstun: .48, knockback: 40, gain: 15, cooldown: .24, lunge: 24 },
      kick:     { windup: .14, active: .13, recover: .28, range: 252, damage: 11, hitstun: .46, knockback: 54, gain: 14, cooldown: .26, lunge: 30 },
      finisher: { windup: .20, active: .18, recover: .40, range: 322, damage: 28, hitstun: .76, knockback: 76, gain: 0,  cooldown: .46, lunge: 34 }
    }
  };

  const ROSTER = {
    grizzly: {
      key: 'grizzly',
      name: 'GOLDEN GRIZZLY',
      shortName: 'GOLDEN GRIZZLY',
      number: '01',
      style: 'POWER',
      from: 'ANCHORAGE, ALASKA',
      height: '6\'8"',
      weight: '302 LBS',
      record: '34-2',
      quote: '"The woods do not fight fair. Neither does he."',
      accent: '#f5b731',
      accentSoft: 'rgba(245,183,49,.24)',
      accentGlow: 'rgba(245,183,49,.40)',
      accentNum: 0xf5b731,
      stats: { POWER: 5, SPEED: 2, STAMINA: 5, TECHNIQUE: 2 },
      heightScale: 1.07,
      healthMult: 1.12,
      speedMult: .87,
      moves: MOVES.grizzly,
      movesName: { quick: 'BEAR SWIPE', power: 'GRIZZLY CLAW', kick: 'TIMBER BOOT', finisher: 'GOLD RUSH' },
      finisherLine: 'GOLD RUSH! THE GRIZZLY IS GOING FOR THE GOLD!',
      ai: { aggression: .78, guard: .18, jump: .05, retreat: .14, prefer: 'power' },
      sprites: {
        idle: 'assets/wrestlers/grizzly_idle.webp',
        strike: 'assets/wrestlers/grizzly_strike.webp',
        kick: 'assets/wrestlers/grizzly_kick.webp',
        down: 'assets/wrestlers/grizzly_down.webp'
      },
      card: 'assets/wrestlers/grizzly_idle.webp'
    },
    crown: {
      key: 'crown',
      name: 'THE CROWN JEWEL',
      shortName: 'CROWN JEWEL',
      number: '02',
      style: 'TECHNICIAN',
      from: 'PALM BEACH, FLORIDA',
      height: '6\'1"',
      weight: '243 LBS',
      record: '52-4',
      quote: '"Every ring is a throne room."',
      accent: '#c99bff',
      accentSoft: 'rgba(123,63,196,.26)',
      accentGlow: 'rgba(170,110,255,.40)',
      accentNum: 0xa66eff,
      stats: { POWER: 3, SPEED: 4, STAMINA: 3, TECHNIQUE: 5 },
      heightScale: .99,
      healthMult: .98,
      speedMult: 1.03,
      moves: MOVES.crown,
      movesName: { quick: 'KNIFE EDGE CHOP', power: 'CROWN BREAKER', kick: 'ROYAL DROPKICK', finisher: 'CROWN DROP' },
      finisherLine: 'CROWN DROP! THE CROWN JEWEL TAKES FLIGHT!',
      ai: { aggression: .55, guard: .40, jump: .12, retreat: .34, prefer: 'quick' },
      sprites: {
        idle: 'assets/wrestlers/crown_idle.webp',
        strike: 'assets/wrestlers/crown_strike.webp',
        kick: 'assets/wrestlers/crown_kick.webp',
        down: 'assets/wrestlers/crown_down.webp'
      },
      card: 'assets/wrestlers/crown_robe.webp'
    },
    junkyard: {
      key: 'junkyard',
      name: 'JUNKYARD KING',
      shortName: 'JUNKYARD KING',
      number: '03',
      style: 'BRAWLER',
      from: 'DETROIT, MICHIGAN',
      height: '6\'3"',
      weight: '281 LBS',
      record: '41-7',
      quote: '"Clean wins are for people with something to lose."',
      accent: '#ff7a5d',
      accentSoft: 'rgba(213,43,43,.24)',
      accentGlow: 'rgba(255,90,50,.38)',
      accentNum: 0xff7a5d,
      stats: { POWER: 4, SPEED: 3, STAMINA: 4, TECHNIQUE: 2 },
      heightScale: 1.03,
      healthMult: 1.08,
      speedMult: .93,
      moves: MOVES.junkyard,
      movesName: { quick: 'CHAIN JAB', power: 'JUNKHOUSE HAMMER', kick: 'SCRAPYARD STOMP', finisher: 'CHAIN REACTION' },
      finisherLine: 'CHAIN REACTION! THE JUNKYARD KING WINDS IT UP!',
      ai: { aggression: .86, guard: .12, jump: .03, retreat: .10, prefer: 'power' },
      sprites: {
        idle: 'assets/wrestlers/junkyard_idle.webp',
        strike: 'assets/wrestlers/junkyard_strike.webp',
        kick: 'assets/wrestlers/junkyard_kick.webp',
        down: 'assets/wrestlers/junkyard_down.webp'
      },
      card: 'assets/wrestlers/junkyard_idle.webp'
    },
    midnight: {
      key: 'midnight',
      name: 'MIDNIGHT MASK',
      shortName: 'MIDNIGHT MASK',
      number: '04',
      style: 'HIGH FLYER',
      from: 'PARTS UNKNOWN',
      height: '6\'0"',
      weight: '228 LBS',
      record: '29-3',
      quote: '"You cannot hit what you cannot see."',
      accent: '#5ee6dd',
      accentSoft: 'rgba(40,184,174,.22)',
      accentGlow: 'rgba(94,230,221,.38)',
      accentNum: 0x5ee6dd,
      stats: { POWER: 2, SPEED: 5, STAMINA: 3, TECHNIQUE: 4 },
      heightScale: .95,
      healthMult: .92,
      speedMult: 1.14,
      moves: MOVES.midnight,
      movesName: { quick: 'LIGHTNING JAB', power: 'THUNDER KICK', kick: 'COMET DROPKICK', finisher: 'MIDNIGHT FLIGHT' },
      finisherLine: 'MIDNIGHT FLIGHT! HE IS OFF THE ROPES!',
      ai: { aggression: .62, guard: .20, jump: .30, retreat: .30, prefer: 'kick' },
      sprites: {
        idle: 'assets/wrestlers/midnight_idle.webp',
        strike: 'assets/wrestlers/midnight_strike.webp',
        kick: 'assets/wrestlers/midnight_kick.webp',
        down: 'assets/wrestlers/midnight_down.webp'
      },
      card: 'assets/wrestlers/midnight_idle.webp'
    }
  };

  const ROSTER_KEYS = Object.keys(ROSTER);

  const VENUES = {
    ring: {
      key: 'ring',
      name: 'THE GOLDEN DOME',
      sub: 'TITLE NIGHT',
      label: 'THE GOLDEN DOME \u00b7 TITLE NIGHT',
      image: 'assets/stages/ring.webp',
      groundSrc: .668,
      anchor: 'center',
      weather: 'spot',
      line: 'THE GOLDEN DOME IS PACKED TO THE RAFTERS!'
    },
    locker: {
      key: 'locker',
      name: 'THE LOCKER ROOM',
      sub: 'BACKSTAGE',
      label: 'THE LOCKER ROOM \u00b7 BACKSTAGE',
      image: 'assets/stages/locker.webp',
      groundSrc: .86,
      anchor: 'bottom',
      weather: 'steam',
      line: 'THE STEAM IS RISING BACKSTAGE!'
    },
    parking: {
      key: 'parking',
      name: 'LOT 13',
      sub: 'AFTER HOURS',
      label: 'LOT 13 \u00b7 AFTER HOURS',
      image: 'assets/stages/parking.webp',
      groundSrc: .87,
      anchor: 'center',
      weather: 'rain',
      line: 'LOT 13 IS WET, DARK AND MEAN TONIGHT!'
    }
  };

  const VENUE_KEYS = Object.keys(VENUES);

  const T = {
    round_seconds: 45,
    player_health: 110,
    rival_health: 100,
    rival_speed: .96,
    impact_stop: .085
  };

  const COMMENTARY = [
    'BOTH FIGHTERS ARE DIGGING DEEP!',
    'THE CROWD IS ON ITS FEET!',
    'THIS ONE IS ALL ABOUT HEART!',
    'NO QUARTER ASKED, NO QUARTER GIVEN!',
    'THE MOMENTUM IS SWINGING LIKE A PENDULUM!',
    'YOU CAN FEEL THE HEAT FROM HERE!',
    'A GOLDEN ERA CLASSIC IN THE MAKING!',
    'THE REFEREE IS LETTING THEM SETTLE IT!'
  ];

  class AudioKit {
    constructor() {
      this.ctx = null;
      this.master = null;
      this.buffers = {};
      this.loops = {};
      this.enabled = true;
      this.inFight = false;
      this.started = false;
    }

    init() {
      if (this.ctx) {
        if (this.ctx.state === 'suspended') { try { this.ctx.resume(); } catch (e) { /* ignore */ } }
        this.started = true;
        this.syncMusic();
        return;
      }
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      try {
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = this.enabled ? .8 : 0;
        this.master.connect(this.ctx.destination);
        this.started = true;
        this.loadAll();
        this.syncMusic();
      } catch (e) {
        this.ctx = null;
      }
    }

    loadAll() {
      const files = {
        theme80: ['assets/audio/theme80.mp3', true],
        fight80: ['assets/audio/fight80.mp3', true],
        crowd_loop: ['assets/audio/crowd_loop.mp3', true],
        hit_punch: ['assets/audio/hit_punch.mp3', false],
        block_clank: ['assets/audio/block_clank.mp3', false],
        whoosh: ['assets/audio/whoosh.mp3', false],
        bell: ['assets/audio/bell.mp3', false],
        stamp_thud: ['assets/audio/stamp_thud.mp3', false],
        ko_roar: ['assets/audio/ko_roar.mp3', false],
        super_bass: ['assets/audio/super_bass.mp3', false],
        finisher_hit: ['assets/audio/finisher_hit.mp3', false],
        pin_slap: ['assets/audio/pin_slap.mp3', false]
      };
      for (const name of Object.keys(files)) {
        const [url, loop] = files[name];
        fetch(url)
          .then((r) => { if (!r.ok) throw new Error('audio'); return r.arrayBuffer(); })
          .then((data) => new Promise((resolve, reject) => this.ctx.decodeAudioData(data, resolve, reject)))
          .then((buffer) => {
            this.buffers[name] = loop ? this.trimLoop(buffer) : buffer;
          })
          .catch(() => null);
      }
    }

    trimLoop(buffer) {
      const ch = buffer.numberOfChannels;
      const len = buffer.length;
      if (!len) return buffer;
      const threshold = .004;
      const data = buffer.getChannelData(0);
      let start = 0;
      let end = len - 1;
      while (start < len && Math.abs(data[start]) < threshold) start++;
      while (end > start && Math.abs(data[end]) < threshold) end--;
      start = Math.max(0, start - 48);
      end = Math.min(len - 1, end + 48);
      const newLen = end - start + 1;
      if (newLen >= len - 8) return buffer;
      const out = this.ctx.createBuffer(ch, newLen, buffer.sampleRate);
      for (let c = 0; c < ch; c++) out.copyToChannel(buffer.getChannelData(c).subarray(start, end + 1), c);
      return out;
    }

    play(name, opts = {}) {
      if (!this.enabled || !this.ctx || !this.buffers[name]) return;
      if (this.ctx.state === 'suspended') { try { this.ctx.resume(); } catch (e) { /* ignore */ } }
      const src = this.ctx.createBufferSource();
      src.buffer = this.buffers[name];
      src.playbackRate.value = opts.rate || 1;
      const gain = this.ctx.createGain();
      gain.gain.value = opts.vol == null ? .8 : opts.vol;
      src.connect(gain);
      gain.connect(this.master);
      try { src.start(); } catch (e) { /* ignore */ }
    }

    startLoop(name, vol) {
      if (!this.ctx || this.loops[name]) return;
      if (this.ctx.state === 'suspended') { try { this.ctx.resume(); } catch (e) { /* ignore */ } }
      if (!this.buffers[name]) {
        let tries = 0;
        const check = setInterval(() => {
          tries++;
          if (this.buffers[name]) { clearInterval(check); this.startLoop(name, vol); }
          else if (tries > 80) { clearInterval(check); delete this.loops[name]; }
        }, 140);
        this.loops[name] = { check };
        return;
      }
      const src = this.ctx.createBufferSource();
      src.buffer = this.buffers[name];
      src.loop = true;
      const gain = this.ctx.createGain();
      gain.gain.value = this.enabled ? vol : 0;
      src.connect(gain);
      gain.connect(this.master);
      try { src.start(); } catch (e) { /* ignore */ }
      this.loops[name] = { src, gain, vol, check: null };
    }

    stopLoop(name) {
      const l = this.loops[name];
      if (!l) return;
      if (l.check) clearInterval(l.check);
      try { if (l.src) l.src.stop(); } catch (e) { /* ignore */ }
      delete this.loops[name];
    }

    syncMusic() {
      if (!this.started || !this.ctx) return;
      if (!this.enabled) {
        Object.keys(this.loops).forEach((k) => this.stopLoop(k));
        return;
      }
      if (this.inFight) {
        this.stopLoop('theme80');
        this.startLoop('crowd_loop', .24);
        this.startLoop('fight80', .17);
      } else {
        this.stopLoop('crowd_loop');
        this.stopLoop('fight80');
        this.startLoop('theme80', .19);
      }
    }

    enterFight() {
      this.inFight = true;
      this.syncMusic();
    }

    leaveFight() {
      this.inFight = false;
      this.syncMusic();
    }

    setEnabled(on) {
      this.enabled = !!on;
      if (this.master) this.master.gain.value = on ? .8 : 0;
      this.syncMusic();
    }
  }

  window.__audio = new AudioKit();

  const unlockAudio = () => { if (window.__audio) window.__audio.init(); };
  document.addEventListener('pointerdown', unlockAudio, { once: true });
  document.addEventListener('keydown', unlockAudio, { once: true });

  const refs = {
    page: $('#page'),
    stickyCta: $('#stickyCta'),
    stickyPick: $('#stickyPick'),
    stickyCtaBtn: $('#stickyCtaBtn'),
    rosterScreen: $('#rosterScreen'),
    matchScreen: $('#matchScreen'),
    fightScreen: $('#fightScreen'),
    rosterGrid: $('#rosterGrid'),
    corner: $('#corner'),
    cornerImg: $('#cornerImg'),
    cornerNo: $('#cornerNo'),
    cornerKicker: $('#cornerKicker'),
    cornerName: $('#cornerName'),
    cornerFrom: $('#cornerFrom'),
    cornerQuote: $('#cornerQuote'),
    cornerStats: $('#cornerStats'),
    cornerMoves: $('#cornerMoves'),
    recordLine: $('#recordLine'),
    toMatchBtn: $('#toMatchBtn'),
    boardList: $('#boardList'),
    boardMine: $('#boardMine'),
    backToRoster: $('#backToRoster'),
    youImg: $('#youImg'),
    youName: $('#youName'),
    youMeta: $('#youMeta'),
    oppList: $('#oppList'),
    venueGrid: $('#venueGrid'),
    matchSummary: $('#matchSummary'),
    startBtn: $('#startBtn'),
    stage: $('#stage'),
    gameMount: $('#gameMount'),
    p1Face: $('#p1Face'),
    p2Face: $('#p2Face'),
    p1Name: $('#p1Name'),
    p2Name: $('#p2Name'),
    p1Health: $('#p1Health'),
    p2Health: $('#p2Health'),
    p1Heat: $('#p1Heat'),
    p2Heat: $('#p2Heat'),
    timerNum: $('#timerNum'),
    fallNum: $('#fallNum'),
    pipsLeft: $('#pipsLeft'),
    pipsRight: $('#pipsRight'),
    commentary: $('#commentary'),
    commentaryText: $('#commentaryText'),
    venueTag: $('#venueTag'),
    venuePlate: $('#venuePlate'),
    combo: $('#combo'),
    comboNum: $('#comboNum'),
    finisherFlash: $('#finisherFlash'),
    finisherName: $('#finisherName'),
    stampLayer: $('#stampLayer'),
    stageLoading: $('#stageLoading'),
    soundBtn: $('#soundBtn'),
    soundTxt: $('#soundTxt'),
    quitBtn: $('#quitBtn'),
    restartBtn: $('#restartBtn'),
    controls: $('#controls'),
    powerBtn: $('.ctrl[data-act="power"]'),
    resultLayer: $('#resultLayer'),
    resultKicker: $('#resultKicker'),
    resultTitle: $('#resultTitle'),
    resultImg: $('#resultImg'),
    resultText: $('#resultText'),
    resultStats: $('#resultStats'),
    rematchBtn: $('#rematchBtn'),
    newMatchBtn: $('#newMatchBtn')
  };

  const S = {
    pick: 'grizzly',
    opponent: 'junkyard',
    venue: 'ring',
    screen: 'roster',
    sceneReady: false,
    afterReady: null,
    matchConfig: null,
    runActive: false,
    runStart: 0,
    soundOn: true,
    userPicked: false,
    profile: { wins: 0, losses: 0, best: null, lastPick: 'grizzly' },
    profileRevision: null,
    profileLoaded: false,
    sdkReady: false,
    resultTimer: null,
    lastStamps: new WeakMap(),
    stampTimer: null,
    comboHide: null
  };

  const UI = {
    powerReady: false,
    timerLast: null,
    healthLast: [null, null],
    heatLast: [null, null],

    setScreen(name) {
      S.screen = name;
      refs.rosterScreen.hidden = name !== 'roster';
      refs.matchScreen.hidden = name !== 'match';
      refs.fightScreen.hidden = name !== 'fight';
      refs.page.classList.toggle('playing', name === 'fight');
      refs.stickyCta.hidden = name !== 'roster';
      if (name !== 'fight') refs.resultLayer.hidden = true;
      try { window.scrollTo(0, 0); } catch (e) { /* ignore */ }
    },

    health(side, fraction) {
      const idx = side === 1 ? 0 : 1;
      const pct = Math.round(clamp(fraction, 0, 1) * 1000) / 10;
      if (this.healthLast[idx] === pct) return;
      this.healthLast[idx] = pct;
      const el = side === 1 ? refs.p1Health : refs.p2Health;
      el.style.width = pct + '%';
      el.classList.toggle('low', pct <= 25);
    },

    heat(side, fraction) {
      const idx = side === 1 ? 0 : 1;
      const pct = Math.round(clamp(fraction, 0, 1) * 1000) / 10;
      if (this.heatLast[idx] === pct) return;
      this.heatLast[idx] = pct;
      const el = side === 1 ? refs.p1Heat : refs.p2Heat;
      el.style.width = pct + '%';
      el.classList.toggle('full', pct >= 99.9);
      if (side === 1 && refs.powerBtn) {
        const ready = pct >= 99.9;
        if (this.powerReady !== ready) {
          this.powerReady = ready;
          refs.powerBtn.classList.toggle('ready', ready);
          const label = refs.powerBtn.querySelector('span');
          if (label) label.textContent = ready ? 'FINISH' : 'POWER';
        }
      }
    },

    timer(seconds) {
      const n = Math.max(0, Math.ceil(seconds));
      if (this.timerLast === n) return;
      this.timerLast = n;
      refs.timerNum.textContent = String(n).padStart(2, '0');
      refs.timerNum.parentElement.classList.toggle('warn', n <= 10);
    },

    pips(a, b) {
      Array.from(refs.pipsLeft.children).forEach((el, i) => el.classList.toggle('on', i < a));
      Array.from(refs.pipsRight.children).forEach((el, i) => el.classList.toggle('on', i < b));
    },

    fall(n) { refs.fallNum.textContent = String(n); },

    names(playerKey, opponentKey) {
      const p = ROSTER[playerKey];
      const o = ROSTER[opponentKey];
      refs.p1Name.textContent = p.shortName || p.name;
      refs.p2Name.textContent = o.shortName || o.name;
      this.face(refs.p1Face, p);
      this.face(refs.p2Face, o);
    },

    face(el, r) {
      const url = ROSTER[r.key].card || ROSTER[r.key].sprites.idle;
      el.style.backgroundImage = 'url("' + url + '")';
    },

    resetFight() {
      this.health(1, 1);
      this.health(2, 1);
      this.heat(1, 0);
      this.heat(2, 0);
      this.timer(T.round_seconds);
      this.fall(1);
      this.pips(0, 0);
      this.combo(0);
      this.clearStamp();
      this.clearFinisher();
      refs.commentaryText.textContent = 'TWO LEGENDS. ONE RING. IT IS TIME TO RUMBLE.';
    },

    namesFor(config) {
      const r = ROSTER[config.player];
      const o = ROSTER[config.opponent];
      const v = VENUES[config.venue];
      refs.venueTag.textContent = v.name;
      refs.venuePlate.textContent = v.label;
      this.names(config.player, config.opponent);
      void r;
      void o;
    },

    commentary(text) {
      refs.commentaryText.textContent = text;
      refs.commentary.style.animation = 'none';
      void refs.commentary.offsetWidth;
      refs.commentary.style.animation = '';
    },

    combo(n) {
      if (n < 2) {
        if (this.comboHide) { clearTimeout(this.comboHide); this.comboHide = null; }
        refs.combo.hidden = true;
        return;
      }
      refs.comboNum.textContent = String(n);
      refs.combo.hidden = false;
      this.comboHide && clearTimeout(this.comboHide);
      this.comboHide = setTimeout(() => { refs.combo.hidden = true; }, 1500);
    },

    stamp(text, opts = {}) {
      if (this.stampTimer) { clearTimeout(this.stampTimer); this.stampTimer = null; }
      refs.stampLayer.replaceChildren();
      if (!text) return;
      if (opts.silent !== true) {
        if (window.__audio) window.__audio.play(opts.sound || 'stamp_thud', { vol: .5 });
      }
      const el = document.createElement('div');
      el.className = 'stamp' + (opts.tone ? ' ' + opts.tone : '');
      el.textContent = text;
      refs.stampLayer.appendChild(el);
      if (opts.hold) {
        this.stampTimer = setTimeout(() => {
          refs.stampLayer.replaceChildren();
          this.stampTimer = null;
        }, opts.hold);
      }
    },

    clearStamp() {
      if (this.stampTimer) { clearTimeout(this.stampTimer); this.stampTimer = null; }
      refs.stampLayer.replaceChildren();
    },

    finisher(name) {
      refs.finisherName.textContent = name;
      refs.finisherFlash.hidden = false;
      refs.finisherFlash.style.animation = 'none';
      void refs.finisherFlash.offsetWidth;
      refs.finisherFlash.style.animation = '';
      setTimeout(() => { refs.finisherFlash.hidden = true; }, 1400);
    },

    clearFinisher() { refs.finisherFlash.hidden = true; },

    loading(on) {
      refs.stageLoading.hidden = !on;
    },

    result(data) {
      refs.resultKicker.textContent = data.kicker;
      refs.resultTitle.textContent = data.title;
      refs.resultTitle.classList.toggle('loss', !data.won);
      refs.resultImg.src = data.image;
      refs.resultText.textContent = data.text;
      refs.resultStats.replaceChildren();
      data.stats.forEach(([label, value]) => {
        const span = document.createElement('span');
        span.className = 'result-stat';
        span.textContent = label + ' ';
        const b = document.createElement('b');
        b.textContent = value;
        span.appendChild(b);
        refs.resultStats.appendChild(span);
      });
      refs.resultLayer.hidden = false;
      if (data.won) this.confetti();
    },

    hideResult() { refs.resultLayer.hidden = true; },

    confetti() {
      const colors = ['#f5b731', '#ffe9a3', '#d52b2b', '#28b8ae', '#c99bff'];
      for (let i = 0; i < 36; i++) {
        const piece = document.createElement('i');
        piece.className = 'confetti';
        piece.style.left = rnd(2, 98) + '%';
        piece.style.background = colors[Math.floor(Math.random() * colors.length)];
        piece.style.animationDuration = rnd(1.8, 3.6) + 's';
        piece.style.animationDelay = rnd(0, .7) + 's';
        piece.style.transform = 'rotate(' + rnd(0, 360) + 'deg)';
        refs.resultLayer.appendChild(piece);
        setTimeout(() => piece.remove(), 4600);
      }
    }
  };

  function fmtTime(sec) {
    if (!isFinite(sec)) return '0:00';
    const s = Math.max(0, Math.round(sec));
    return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  }

  function fmtTimeTenths(sec) {
    if (!isFinite(sec)) return '0:00.0';
    const tenths = Math.max(0, Math.round(sec * 10));
    const s = Math.floor(tenths / 10);
    return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0') + '.' + (tenths % 10);
  }

  function preloadImages() {
    const paths = [];
    ROSTER_KEYS.forEach((key) => {
      const r = ROSTER[key];
      Object.values(r.sprites).forEach((p) => paths.push(p));
      if (r.card) paths.push(r.card);
    });
    VENUE_KEYS.forEach((k) => paths.push(VENUES[k].image));
    paths.push('assets/ui/belt.webp');
    for (const src of paths) {
      const im = new Image();
      im.src = src;
    }
  }

  function buildRoster() {
    refs.rosterGrid.replaceChildren();
    ROSTER_KEYS.forEach((key) => {
      const r = ROSTER[key];
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'roster-card';
      btn.dataset.key = key;
      btn.style.setProperty('--accent', r.accent);
      btn.style.setProperty('--accent-soft', r.accentSoft);
      btn.style.setProperty('--accent-glow', r.accentGlow);
      btn.setAttribute('aria-pressed', 'false');
      const no = document.createElement('span');
      no.className = 'card-no';
      no.textContent = r.number;
      const tag = document.createElement('span');
      tag.className = 'card-tag';
      tag.textContent = r.style;
      const img = document.createElement('img');
      img.className = 'card-art';
      img.src = r.card;
      img.alt = r.name;
      const info = document.createElement('span');
      info.className = 'card-info';
      const name = document.createElement('span');
      name.className = 'card-name';
      name.textContent = r.name;
      const style = document.createElement('span');
      style.className = 'card-style';
      style.textContent = r.record + ' \u00b7 ' + r.weight;
      info.append(name, style);
      btn.append(no, tag, img, info);
      btn.addEventListener('click', () => selectFighter(key, true));
      refs.rosterGrid.appendChild(btn);
    });
  }

  function selectFighter(key, user = false) {
    const r = ROSTER[key];
    if (!r) return;
    if (user) S.userPicked = true;
    S.pick = key;
    if (S.opponent === key) {
      S.opponent = ROSTER_KEYS.find((k) => k !== key) || S.opponent;
    }
    $$('.roster-card', refs.rosterGrid).forEach((card) => {
      const on = card.dataset.key === key;
      card.classList.toggle('is-picked', on);
      card.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    refs.corner.style.setProperty('--accent', r.accent);
    refs.corner.style.setProperty('--accent-soft', r.accentSoft);
    refs.corner.style.setProperty('--accent-glow', r.accentGlow);
    refs.cornerImg.src = r.card;
    refs.cornerImg.alt = r.name;
    refs.cornerNo.textContent = r.number;
    refs.cornerKicker.textContent = r.style + ' \u00b7 ' + r.height + ' \u00b7 ' + r.weight;
    refs.cornerName.textContent = r.name;
    refs.cornerFrom.textContent = 'FROM ' + r.from;
    refs.cornerQuote.textContent = r.quote;
    refs.cornerStats.replaceChildren();
    Object.entries(r.stats).forEach(([label, value]) => {
      const row = document.createElement('div');
      row.className = 'stat';
      const lab = document.createElement('span');
      lab.textContent = label;
      const segs = document.createElement('span');
      segs.className = 'stat-segs';
      for (let i = 0; i < 5; i++) {
        const seg = document.createElement('i');
        if (i < value) seg.className = 'on';
        segs.appendChild(seg);
      }
      row.append(lab, segs);
      refs.cornerStats.appendChild(row);
    });
    refs.cornerMoves.replaceChildren();
    [['quick', 'QUICK'], ['power', 'POWER'], ['kick', 'KICK'], ['finisher', 'FINISHER']].forEach(([type, label]) => {
      const chip = document.createElement('span');
      chip.className = 'move-chip';
      const b = document.createElement('b');
      b.textContent = label + ' ';
      chip.append(b, document.createTextNode(r.movesName[type]));
      refs.cornerMoves.appendChild(chip);
    });
    refs.youImg.src = r.card;
    refs.youName.textContent = r.name;
    refs.youMeta.textContent = r.style + ' \u00b7 ' + r.weight;
    refs.stickyPick.textContent = r.name;
    buildOpponents();
    updateMatchSummary();
    Promise.resolve()
      .then(() => saveProfilePick(key))
      .catch(() => {});
  }

  function buildOpponents() {
    refs.oppList.replaceChildren();
    ROSTER_KEYS.filter((k) => k !== S.pick).forEach((key) => {
      const r = ROSTER[key];
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'opp-card';
      btn.dataset.key = key;
      btn.style.setProperty('--accent', r.accent);
      btn.setAttribute('aria-pressed', key === S.opponent ? 'true' : 'false');
      const img = document.createElement('img');
      img.src = r.card;
      img.alt = r.name;
      const copy = document.createElement('span');
      const name = document.createElement('span');
      name.className = 'opp-name';
      name.textContent = r.name;
      const style = document.createElement('span');
      style.className = 'opp-style';
      style.textContent = r.style + ' \u00b7 ' + r.record;
      copy.append(name, style);
      const mark = document.createElement('span');
      mark.className = 'opp-mark';
      mark.textContent = 'PICK';
      btn.append(img, copy, mark);
      btn.addEventListener('click', () => selectOpponent(key));
      refs.oppList.appendChild(btn);
      if (key === S.opponent) btn.classList.add('is-picked');
    });
  }

  function selectOpponent(key) {
    if (key === S.pick || !ROSTER[key]) return;
    S.opponent = key;
    $$('.opp-card', refs.oppList).forEach((card) => {
      const on = card.dataset.key === key;
      card.classList.toggle('is-picked', on);
      card.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    updateMatchSummary();
  }

  function buildVenues() {
    refs.venueGrid.replaceChildren();
    VENUE_KEYS.forEach((key) => {
      const v = VENUES[key];
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'venue-card' + (key === S.venue ? ' is-picked' : '');
      btn.dataset.key = key;
      btn.setAttribute('aria-pressed', key === S.venue ? 'true' : 'false');
      const img = document.createElement('img');
      img.src = v.image;
      img.alt = v.name;
      const label = document.createElement('span');
      label.className = 'venue-label';
      const name = document.createElement('span');
      name.className = 'venue-name';
      name.textContent = v.name;
      const sub = document.createElement('span');
      sub.className = 'venue-sub';
      sub.textContent = v.sub;
      label.append(name, sub);
      const pick = document.createElement('span');
      pick.className = 'venue-pick';
      pick.textContent = 'SELECTED';
      btn.append(img, label, pick);
      btn.addEventListener('click', () => selectVenue(key));
      refs.venueGrid.appendChild(btn);
    });
  }

  function selectVenue(key) {
    if (!VENUES[key]) return;
    S.venue = key;
    $$('.venue-card', refs.venueGrid).forEach((card) => {
      const on = card.dataset.key === key;
      card.classList.toggle('is-picked', on);
      card.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    updateMatchSummary();
  }

  function updateMatchSummary() {
    const p = ROSTER[S.pick];
    const o = ROSTER[S.opponent] || ROSTER[ROSTER_KEYS.find((k) => k !== S.pick)];
    const v = VENUES[S.venue];
    if (!o || !v) return;
    refs.matchSummary.replaceChildren();
    const line1 = document.createElement('div');
    line1.innerHTML = '<b>' + p.name + '</b> VS <b>' + o.name + '</b>';
    const line2 = document.createElement('div');
    line2.textContent = v.label + ' \u00b7 TWO FALLS TO WIN \u00b7 FILL HEAT FOR YOUR FINISHER';
    refs.matchSummary.append(line1, line2);
    refs.youImg.src = p.card;
    refs.youName.textContent = p.name;
    refs.youMeta.textContent = p.style + ' \u00b7 ' + p.weight;
  }

  async function loadTune() {
    const mb = MB();
    if (mb && typeof mb.tune === 'function') {
      try {
        const values = await mb.tune();
        if (values && typeof values === 'object') Object.assign(T, values);
      } catch (e) { /* defaults stay */ }
      if (typeof mb.tune.on === 'function') {
        mb.tune.on((next) => { if (next && typeof next === 'object') Object.assign(T, next); });
      }
      return;
    }
    try {
      const file = await fetch('tune.json').then((r) => r.json());
      const values = {};
      for (const [k, e] of Object.entries(file)) values[k] = e.value;
      Object.assign(T, values);
    } catch (e) { /* defaults stay */ }
  }

  async function refreshBoard() {
    const mb = MB();
    if (!mb || !mb.leaderboard) return;
    try {
      const rows = await mb.leaderboard.top('main_event_time', { limit: 5 });
      const list = refs.boardList;
      list.replaceChildren();
      if (!rows || !rows.length) {
        const li = document.createElement('li');
        li.className = 'board-empty';
        li.textContent = 'NO RECORDS YET. BE THE FIRST.';
        list.appendChild(li);
      } else {
        rows.forEach((row) => {
          const li = document.createElement('li');
          if (row.mine) li.classList.add('mine');
          const rank = document.createElement('span');
          rank.className = 'rank';
          rank.textContent = String(row.rank) + '.';
          const who = document.createElement('span');
          who.className = 'who';
          if (row.profile_url) {
            const a = document.createElement('a');
            a.href = row.profile_url;
            a.textContent = row.username || 'guest';
            a.target = '_blank';
            a.rel = 'noopener';
            who.appendChild(a);
          } else {
            who.textContent = row.username || 'guest';
          }
          const time = document.createElement('span');
          time.className = 'time';
          time.textContent = fmtTimeTenths(row.value);
          li.append(rank, who, time);
          list.appendChild(li);
        });
      }
      try {
        const mine = await mb.leaderboard.mine('main_event_time');
        refs.boardMine.textContent = mine && isFinite(mine.value) ? 'YOUR BEST ' + fmtTimeTenths(mine.value) : '';
      } catch (e) {
        refs.boardMine.textContent = '';
      }
    } catch (e) { /* a board that cannot be read is left empty */ }
  }

  function submitTime(seconds) {
    const mb = MB();
    if (!mb || !mb.leaderboard) return;
    mb.leaderboard
      .submit('main_event_time', Math.round(seconds * 10) / 10, { lower: true, label: 'Fastest main event' })
      .then(refreshBoard)
      .catch(() => {});
  }

  function updateRecordLine() {
    refs.recordLine.textContent = 'YOUR RECORD ' + S.profile.wins + '-' + S.profile.losses;
  }

  async function loadProfile() {
    const mb = MB();
    if (!mb || !mb.load) return;
    try {
      const saved = await mb.load('rumble_profile');
      S.profileRevision = saved ? saved.revision : null;
      const value = saved && saved.value;
      if (value && typeof value === 'object') {
        S.profile.wins = Number(value.wins) || 0;
        S.profile.losses = Number(value.losses) || 0;
        S.profile.best = isFinite(value.best) ? Number(value.best) : null;
        if (ROSTER[value.lastPick] && !S.userPicked) {
          selectFighter(value.lastPick, false);
        }
      }
      S.profileLoaded = true;
      updateRecordLine();
    } catch (e) { /* profile is optional */ }
  }

  async function saveProfilePick(key) {
    if (!S.profileLoaded) return;
    S.profile.lastPick = key;
    await saveProfile();
  }

  async function saveProfile(next) {
    const mb = MB();
    if (!mb || !mb.save) return;
    if (!S.profileLoaded) return;
    const payload = {
      schemaVersion: 1,
      wins: S.profile.wins,
      losses: S.profile.losses,
      best: S.profile.best,
      lastPick: S.profile.lastPick
    };
    if (next) Object.assign(payload, next);
    try {
      const result = await mb.save('rumble_profile', payload, S.profileRevision ? { ifRevision: S.profileRevision } : undefined);
      S.profileRevision = result ? result.revision : S.profileRevision;
    } catch (e) {
      if (e && e.reason === 'REVISION_CONFLICT' && e.current) {
        try {
          const fresh = await mb.load('rumble_profile');
          S.profileRevision = fresh ? fresh.revision : null;
          const value = fresh && fresh.value;
          if (value && typeof value === 'object') {
            S.profile.wins = Number(value.wins) || 0;
            S.profile.losses = Number(value.losses) || 0;
            S.profile.best = isFinite(value.best) ? Number(value.best) : null;
          }
          updateRecordLine();
        } catch (err) { /* keep local record */ }
      }
    }
  }

  async function recordMatch(result) {
    S.profile.wins += result.won ? 1 : 0;
    S.profile.losses += result.won ? 0 : 1;
    if (result.won && (!S.profile.best || result.seconds < S.profile.best)) {
      S.profile.best = result.seconds;
    }
    updateRecordLine();
    await saveProfile({ lastPick: S.pick });
  }

  function setupSdk() {
    const mb = MB();
    if (!mb) return;
    S.sdkReady = true;
    try {
      mb.measure && mb.measure([
        { name: 'match_won', kind: 'count', label: 'Main events won' },
        { name: 'match_lost', kind: 'count', label: 'Main events lost' },
        { name: 'main_event_time', kind: 'value', label: 'Match time (s)' },
        { name: 'finisher', kind: 'count', label: 'Finishers used' },
        { name: 'fall_won', kind: 'count', label: 'Falls won' }
      ]);
    } catch (e) { /* measurement is optional */ }
    loadTune();
    if (mb.sound) {
      S.soundOn = !!mb.sound.on;
      if (typeof mb.sound.onchange === 'function') {
        mb.sound.onchange((on) => { S.soundOn = !!on; syncSound(); });
      }
    }
    syncSound();
    loadProfile();
    refreshBoard();
  }

  function syncSound() {
    refs.soundBtn.setAttribute('aria-pressed', S.soundOn ? 'true' : 'false');
    refs.soundTxt.textContent = S.soundOn ? 'SOUND ON' : 'SOUND OFF';
    const mb = MB();
    if (mb && mb.sound && typeof mb.sound.set === 'function' && mb.sound.on !== S.soundOn) {
      try { mb.sound.set(S.soundOn); } catch (e) { /* keep local switch */ }
    }
    if (window.__audio) window.__audio.setEnabled(S.soundOn);
  }

  refs.soundBtn.addEventListener('click', () => {
    const mb = MB();
    if (mb && mb.sound && typeof mb.sound.toggle === 'function') {
      try { S.soundOn = !!mb.sound.toggle(); } catch (e) { S.soundOn = !S.soundOn; }
    } else {
      S.soundOn = !S.soundOn;
    }
    syncSound();
  });

  function startRun() {
    if (S.runActive) return;
    S.runActive = true;
    S.runStart = performance.now();
    if (window.__audio) window.__audio.enterFight();
    try { MB()?.run?.start?.(); } catch (e) { /* no run seam */ }
  }

  function endRun(props) {
    if (!S.runActive) return;
    S.runActive = false;
    try { MB()?.run?.end?.(props); } catch (e) { /* no run seam */ }
  }

  function showRoster() {
    if (S.resultTimer) { clearTimeout(S.resultTimer); S.resultTimer = null; }
    const scene = window.__scene;
    if (scene && typeof scene.stopMatch === 'function') scene.stopMatch();
    if (window.__audio) window.__audio.leaveFight();
    endRun({ seconds: 0, won: false, retired: true });
    UI.hideResult();
    UI.clearStamp();
    UI.combo(0);
    UI.setScreen('roster');
    refreshBoard();
  }

  function showMatch() {
    UI.setScreen('match');
    buildOpponents();
    buildVenues();
    updateMatchSummary();
    syncAllPicks();
    preloadImages();
  }

  function syncSyncButtons() {
    $$('.roster-card', refs.rosterGrid).forEach((card) => {
      const on = card.dataset.key === S.pick;
      card.classList.toggle('is-picked', on);
      card.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    $$('.opp-card', refs.oppList).forEach((card) => {
      const on = card.dataset.key === S.opponent;
      card.classList.toggle('is-picked', on);
      card.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    $$('.venue-card', refs.venueGrid).forEach((card) => {
      const on = card.dataset.key === S.venue;
      card.classList.toggle('is-picked', on);
      card.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
  }

  function syncAllPicks() { syncSyncButtons(); }

  function showFight() {
    UI.setScreen('fight');
    UI.namesFor({ player: S.pick, opponent: S.opponent, venue: S.venue });
    UI.resetFight();
  }

  function startMatch() {
    if (S.resultTimer) { clearTimeout(S.resultTimer); S.resultTimer = null; }
    const existing = window.__scene;
    if (S.runActive) {
      if (existing && typeof existing.stopMatch === 'function') existing.stopMatch();
      endRun({ seconds: 0, won: false, retired: true });
    }
    const config = {
      player: S.pick,
      opponent: S.opponent,
      venue: S.venue,
      onBell: () => startRun(),
      onEnd: onMatchEnd
    };
    S.matchConfig = config;
    UI.hideResult();
    showFight();
    const scene = window.__scene;
    if (scene && typeof scene.beginMatch === 'function') {
      UI.loading(false);
      scene.beginMatch(config);
    } else {
      S.afterReady = config;
      UI.loading(true);
      ensureGame();
    }
  }

  function onMatchEnd(result) {
    endRun({
      seconds: Math.round(result.seconds),
      won: !!result.won,
      opponent: result.opponent,
      venue: result.venue,
      falls: result.wins[0] + '-' + result.wins[1]
    });
    try {
      MB()?.event?.(result.won ? 'match_won' : 'match_lost', {
        opponent: result.opponent,
        venue: result.venue,
        seconds: Math.round(result.seconds)
      });
      MB()?.event?.('main_event_time', { value: Math.round(result.seconds * 10) / 10 });
    } catch (e) { /* events are optional */ }
    recordMatch(result);
    if (result.won) submitTime(result.seconds);
    if (S.resultTimer) { clearTimeout(S.resultTimer); S.resultTimer = null; }
    S.resultTimer = setTimeout(() => {
      S.resultTimer = null;
      const p = ROSTER[result.player];
      const o = ROSTER[result.opponent];
      const v = VENUES[result.venue];
      const method = result.reason === 'pin' ? 'PINFALL' : 'TIME LIMIT';
      UI.result({
        won: result.won,
        kicker: 'THE FINAL BELL',
        title: result.won ? 'WINNER' : 'DEFEAT',
        image: p.card,
        text: result.won
          ? p.name + ' TAKES THE MAIN EVENT IN ' + fmtTime(result.seconds) + ' BY ' + method + '.'
          : o.name + ' TAKES THE MAIN EVENT AT ' + v.name + ' BY ' + method + '.',
        stats: [
          ['TIME', fmtTime(result.seconds)],
          ['FALLS', result.wins[0] + '-' + result.wins[1]],
          ['METHOD', method],
          ['VENUE', v.name],
          ['RECORD', S.profile.wins + '-' + S.profile.losses]
        ]
      });
    }, 1300);
  }

  function quitMatch() {
    const scene = window.__scene;
    if (scene && typeof scene.stopMatch === 'function') scene.stopMatch();
    endRun({ seconds: 0, won: false, retired: true });
    showRoster();
  }

  refs.toMatchBtn.addEventListener('click', showMatch);
  refs.stickyCtaBtn.addEventListener('click', showMatch);
  refs.backToRoster.addEventListener('click', showRoster);
  refs.startBtn.addEventListener('click', startMatch);
  refs.quitBtn.addEventListener('click', quitMatch);
  refs.restartBtn.addEventListener('click', () => {
    if (S.matchConfig) startMatch();
  });
  refs.rematchBtn.addEventListener('click', () => {
    UI.hideResult();
    startMatch();
  });
  refs.newMatchBtn.addEventListener('click', () => {
    UI.hideResult();
    showRoster();
  });

  document.addEventListener('keydown', (e) => {
    const key = e.key;
    if (!refs.resultLayer.hidden) {
      if (key === 'Enter' || key === ' ') {
        e.preventDefault();
        UI.hideResult();
        startMatch();
      }
      return;
    }
    if (S.screen === 'roster') {
      if (key === ' ' || key === 'Enter') {
        e.preventDefault();
        showMatch();
      }
      return;
    }
    if (S.screen === 'match') {
      if (key === ' ' || key === 'Enter') {
        e.preventDefault();
        startMatch();
      } else if (key === 'Escape') {
        e.preventDefault();
        showRoster();
      }
      return;
    }
    if (S.screen !== 'fight') return;
    if (key === 'Escape') { e.preventDefault(); quitMatch(); return; }
    const scene = window.__scene;
    if (!scene) return;
    const k = key.length === 1 ? key.toLowerCase() : key;
    if (k === 'ArrowLeft' || k === 'a') { e.preventDefault(); scene.hold('left', true); }
    else if (k === 'ArrowRight' || k === 'd') { e.preventDefault(); scene.hold('right', true); }
    else if (k === ' ' || k === 'ArrowUp' || k === 'w') {
      e.preventDefault();
      if (!e.repeat) scene.press('jump');
    }
    else if (k === 'z' || k === 'j') { e.preventDefault(); if (!e.repeat) scene.press('quick'); }
    else if (k === 'x' || k === 'k') { e.preventDefault(); if (!e.repeat) scene.press('power'); }
    else if (k === 'v' || k === 'b') { e.preventDefault(); if (!e.repeat) scene.press('kick'); }
    else if (k === 'c' || k === 'l' || k === 'Shift') { e.preventDefault(); scene.hold('guard', true); }
  });

  document.addEventListener('keyup', (e) => {
    const scene = window.__scene;
    if (!scene) return;
    const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    if (k === 'ArrowLeft' || k === 'a') scene.hold('left', false);
    else if (k === 'ArrowRight' || k === 'd') scene.hold('right', false);
    else if (k === 'c' || k === 'l' || k === 'Shift') scene.hold('guard', false);
  });

  window.addEventListener('blur', () => {
    const scene = window.__scene;
    if (scene && typeof scene.releaseAll === 'function') scene.releaseAll();
  });

  function wireControls() {
    $$('.ctrl').forEach((btn) => {
      const act = btn.getAttribute('data-act');
      const down = (e) => {
        e.preventDefault();
        if (!refs.resultLayer.hidden) return;
        const scene = window.__scene;
        if (!scene) return;
        btn.classList.add('is-down');
        if (act === 'left' || act === 'right' || act === 'guard') scene.hold(act, true);
        else scene.press(act);
        if (btn.setPointerCapture && e.pointerId != null) {
          try { btn.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
        }
      };
      const up = (e) => {
        e.preventDefault();
        const scene = window.__scene;
        btn.classList.remove('is-down');
        if (scene && (act === 'left' || act === 'right' || act === 'guard')) scene.hold(act, false);
      };
      btn.addEventListener('pointerdown', down);
      btn.addEventListener('pointerup', up);
      btn.addEventListener('pointercancel', up);
      btn.addEventListener('pointerleave', (e) => { if (e.buttons) up(e); });
      btn.addEventListener('contextmenu', (e) => e.preventDefault());
    });
  }

  function ensureGame() {
    if (window.__game) return;
    if (!window.Phaser) {
      UI.loading(false);
      UI.stamp('THE LIGHTS ARE OUT', { hold: 2500, tone: 'red' });
      return;
    }
    const FightScene = makeFightScene();
    window.__game = new Phaser.Game({
      type: Phaser.CANVAS,
      parent: 'gameMount',
      backgroundColor: '#080503',
      transparent: false,
      scale: {
        mode: Phaser.Scale.RESIZE,
        width: 900,
        height: 700
      },
      render: { antialias: true, roundPixels: false },
      audio: { noAudio: true },
      scene: [FightScene]
    });
  }

  function makeFightScene() {
    class FightScene extends Phaser.Scene {
      constructor() { super('fight'); }

      preload() {
        ROSTER_KEYS.forEach((key) => {
          const r = ROSTER[key];
          this.load.image(key + '_idle', r.sprites.idle);
          this.load.image(key + '_strike', r.sprites.strike);
          this.load.image(key + '_kick', r.sprites.kick);
          this.load.image(key + '_down', r.sprites.down);
        });
        VENUE_KEYS.forEach((key) => {
          this.load.image('venue_' + key, VENUES[key].image);
        });
      }

      create() {
        this.W = this.scale.width || refs.stage.clientWidth || 390;
        this.H = this.scale.height || refs.stage.clientHeight || 560;
        this.unit = this.H / 700;
        this.groundY = this.H * .72;
        this.venueKey = 'ring';
        this.playerKey = 'grizzly';
        this.opponentKey = 'junkyard';

        this.backdrop = this.add.image(0, 0, 'venue_ring').setOrigin(0, 0).setDepth(0);
        this.flash = this.add.rectangle(0, 0, this.W, this.H, 0xffe9a3, 0).setOrigin(0, 0).setDepth(2.2);
        this.spot = this.add.graphics().setDepth(1.1);
        this.weather = this.add.graphics().setDepth(1.15);
        this.fx = this.add.graphics().setDepth(4);

        this.p1B = this.add.image(0, 0, 'grizzly_idle').setOrigin(.5, 1).setDepth(2.8).setAlpha(.45).setVisible(false);
        this.p2B = this.add.image(0, 0, 'junkyard_idle').setOrigin(.5, 1).setDepth(2.8).setAlpha(.45).setVisible(false);
        this.p1S = this.add.image(0, 0, 'grizzly_idle').setOrigin(.5, 1).setDepth(3).setVisible(false);
        this.p2S = this.add.image(0, 0, 'junkyard_idle').setOrigin(.5, 1).setDepth(3.02).setVisible(false);

        this.particles = [];
        this.waves = [];
        this.motes = [];
        this.rain = [];
        this.stop = 0;
        this.shakeUntil = 0;
        this.ambientT = 0;
        this.commentaryT = 0;
        this.lastTimer = null;
        this.idleClock = 0;

        this.p1 = this.makeFighter('grizzly', 1);
        this.p2 = this.makeFighter('junkyard', 2);

        this.match = {
          active: false,
          phase: 'idle',
          fall: 1,
          wins: [0, 0],
          time: T.round_seconds,
          seconds: 0,
          roundWinner: null,
          reason: 'pin',
          onEnd: null,
          onBell: null,
          bellRung: false,
          finisherUsed: 0,
          timers: []
        };

        this.playerInput = this.blankInput();
        this.aiInput = this.blankInput();
        this.ai = { think: 0, attackCd: 0, guard: 0, jumpCd: 0 };
        this.combo = 0;
        this.comboT = 0;

        this.layout();
        this.scale.on('resize', () => this.layout());

        window.__scene = this;
        S.sceneReady = true;
        document.dispatchEvent(new Event('scene-ready'));
      }

      blankInput() {
        return { left: false, right: false, guard: false, jump: false, quick: false, power: false, kick: false };
      }

      makeFighter(key, side) {
        const r = ROSTER[key];
        const base = side === 1 ? T.player_health : T.rival_health;
        const max = Math.round(base * r.healthMult);
        return {
          key,
          side,
          x: 0,
          facing: side === 1 ? 1 : -1,
          health: max,
          max,
          meter: 0,
          state: 'idle',
          attack: null,
          jumpY: 0,
          velY: 0,
          hitTimer: 0,
          knockV: 0,
          walkT: 0,
          idleT: rnd(0, 10),
          cd: 0,
          finisherReady: false,
          shown: false
        };
      }

      applyTune(values) { Object.assign(T, values || {}); }

      rivalMax() {
        return Math.round(T.rival_health * ROSTER[this.opponentKey].healthMult);
      }

      layout() {
        const w = this.scale.width || (refs.stage && refs.stage.clientWidth) || 390;
        const h = this.scale.height || (refs.stage && refs.stage.clientHeight) || 560;
        const oldW = this.W || w;
        const oldH = this.H || h;
        this.W = Math.max(1, w);
        this.H = Math.max(1, h);
        this.unit = this.H / 700;
        const venue = VENUES[this.venueKey] || VENUES.ring;

        this.setBackdrop();
        const gy = this.bgY + this.bgImgH * this.bgScale * venue.groundSrc;
        this.groundY = clamp(gy, this.H * .5, this.H * .9);
        this.drawSpotlights();
        this.setSpritesScale();
        this.seatFighters();
        this.syncSpritePositions();
        this.resetWeather();

        if (this.p1 && this.p2 && this.match.active && oldW > 1) {
          const ratio = this.W / oldW;
          this.p1.x = clamp(this.p1.x * ratio, this.W * .12, this.W * .88);
          this.p2.x = clamp(this.p2.x * ratio, this.W * .12, this.W * .88);
          this.p1.jumpY *= this.H / Math.max(1, oldH);
          this.p2.jumpY *= this.H / Math.max(1, oldH);
        }
      }

      setBackdrop() {
        const key = 'venue_' + this.venueKey;
        const img = this.textures.get(key).getSourceImage();
        const scale = Math.max(this.W / img.width, this.H / img.height);
        const bx = (this.W - img.width * scale) / 2;
        const venue = VENUES[this.venueKey] || VENUES.ring;
        const by = venue.anchor === 'bottom'
          ? this.H - img.height * scale
          : (this.H - img.height * scale) / 2;
        this.bgImgH = img.height;
        this.bgScale = scale;
        this.bgX = bx;
        this.bgY = by;
        this.backdrop.setTexture(key).setScale(scale).setPosition(bx, by).setDepth(0);
        this.flash.setPosition(0, 0).setSize(this.W, this.H);
      }

      drawSpotlights() {
        const g = this.spot;
        g.clear();
        if (this.venueKey === 'ring') {
          const top = this.H * .04;
          for (let i = 0; i < 4; i++) {
            const x = this.W * (.14 + i * .24);
            g.fillStyle(0xffe9a3, .035 + (i % 2) * .015);
            g.beginPath();
            g.moveTo(x, top);
            g.lineTo(x - this.W * .13, this.groundY + this.H * .06);
            g.lineTo(x + this.W * .13, this.groundY + this.H * .06);
            g.closePath();
            g.fillPath();
          }
          g.fillStyle(0xf5b731, .02);
          g.fillRect(0, this.groundY - 2 * this.unit, this.W, this.H * .12);
        } else if (this.venueKey === 'locker') {
          g.fillStyle(0xdff7ff, .035);
          g.fillRect(this.W * .2, 0, this.W * .16, this.H);
          g.fillRect(this.W * .66, 0, this.W * .12, this.H);
        } else {
          g.fillStyle(0x28b8ae, .025);
          g.fillRect(0, 0, this.W, this.H * .34);
        }
      }

      setSpritesScale() {
        const scaleFor = (key) => {
          const r = ROSTER[key];
          const idle = this.textures.get(key + '_idle').getSourceImage();
          const target = Math.min(this.H * .49, this.W * .56) * r.heightScale;
          return target / idle.height;
        };
        this.p1Scale = scaleFor(this.playerKey);
        this.p2Scale = scaleFor(this.opponentKey);
        this.p1S.setScale(this.p1Scale);
        this.p2S.setScale(this.p2Scale);
        this.p1B.setScale(this.p1Scale * 1.025);
        this.p2B.setScale(this.p2Scale * 1.025);
      }

      seatFighters() {
        if (!this.p1 || !this.p2) return;
        if (!this.match.active) {
          this.p1.x = this.W * .33;
          this.p2.x = this.W * .67;
        }
        this.p1.x = clamp(this.p1.x, this.W * .12, this.W * .88);
        this.p2.x = clamp(this.p2.x, this.W * .12, this.W * .88);
        const minGap = 155 * this.unit;
        if (this.p2.x - this.p1.x < minGap) {
          const mid = (this.p1.x + this.p2.x) / 2;
          this.p1.x = mid - minGap / 2;
          this.p2.x = mid + minGap / 2;
        }
      }

      resetWeather() {
        this.motes.length = 0;
        this.rain.length = 0;
        const n = this.venueKey === 'ring' ? 26 : (this.venueKey === 'locker' ? 22 : 60);
        for (let i = 0; i < n; i++) {
          if (this.venueKey === 'parking') {
            this.rain.push({ x: rnd(-this.W * .2, this.W * 1.2), y: rnd(-this.H, this.H), len: rnd(8, 24) * this.unit, sp: rnd(360, 680) * this.unit, a: rnd(.1, .3) });
          } else {
            this.motes.push({
              x: rnd(0, this.W),
              y: rnd(0, this.H),
              r: rnd(1, 3) * this.unit,
              vx: rnd(-12, 12) * this.unit,
              vy: rnd(-20, -4) * this.unit,
              a: rnd(.08, .28)
            });
          }
        }
      }

      beginMatch(config) {
        this.clearTimers();
        this.playerKey = config.player;
        this.opponentKey = config.opponent;
        this.venueKey = config.venue;
        this.match.onEnd = config.onEnd;
        this.match.onBell = config.onBell;
        this.match.active = true;
        this.match.phase = 'intro';
        this.match.fall = 1;
        this.match.wins = [0, 0];
        this.match.seconds = 0;
        this.match.time = T.round_seconds;
        this.match.roundWinner = null;
        this.match.reason = 'pin';
        this.match.bellRung = false;
        this.match.finisherUsed = 0;
        this.match.playerKey = config.player;
        this.match.opponentKey = config.opponent;
        this.match.venueKey = config.venue;

        this.p1 = this.makeFighter(config.player, 1);
        this.p2 = this.makeFighter(config.opponent, 2);
        this.p1S.setTexture(config.player + '_idle').setVisible(true);
        this.p1B.setTexture(config.player + '_idle').setVisible(true);
        this.p2S.setTexture(config.opponent + '_idle').setVisible(true);
        this.p2B.setTexture(config.opponent + '_idle').setVisible(true);
        this.p1S.clearTint();
        this.p2S.clearTint();
        this.playerInput = this.blankInput();
        this.aiInput = this.blankInput();
        this.ai = { think: .45, attackCd: .9, guard: 0, jumpCd: .4 };
        this.combo = 0;
        this.comboT = 0;
        this.venueKey = config.venue;
        if (this.scale && typeof this.scale.refresh === 'function') this.scale.refresh();
        this.setSpritesScale();
        this.layout();
        this.resetRoundPositions();
        UI.pips(0, 0);
        UI.combo(0);
        UI.fall(1);
        UI.commentary(VENUES[config.venue].line);
        this.startFall(1);
      }

      stopMatch() {
        this.clearTimers();
        this.match.active = false;
        this.match.phase = 'idle';
        if (this.p1S) this.p1S.setVisible(false);
        if (this.p2S) this.p2S.setVisible(false);
        if (this.p1B) { this.p1B.setVisible(false); this.p1B.setAlpha(.45); }
        if (this.p2B) { this.p2B.setVisible(false); this.p2B.setAlpha(.45); }
        this.p1S && this.p1S.clearTint();
        this.p2S && this.p2S.clearTint();
        this.p1S && this.p1S.setAngle(0);
        this.p2S && this.p2S.setAngle(0);
        this.p1B && this.p1B.setAngle(0);
        this.p2B && this.p2B.setAngle(0);
        this.fx && this.fx.clear();
        this.flash && this.flash.setAlpha(0);
        this.particles.length = 0;
        this.waves.length = 0;
        this.match.onEnd = null;
        this.match.onBell = null;
        if (window.__audio) window.__audio.leaveFight();
      }

      clearTimers() {
        this.match.timers.forEach((t) => { if (t && t.remove) t.remove(); });
        this.match.timers = [];
      }

      later(ms, fn) {
        const t = this.time.delayedCall(ms, () => {
          this.match.timers = this.match.timers.filter((x) => x !== t);
          fn();
        });
        this.match.timers.push(t);
        return t;
      }

      resetRoundPositions() {
        this.p1.x = this.W * .33;
        this.p2.x = this.W * .67;
        this.p1.facing = 1;
        this.p2.facing = -1;
        this.p1.jumpY = 0;
        this.p2.jumpY = 0;
        this.p1.velY = 0;
        this.p2.velY = 0;
        this.p1.knockV = 0;
        this.p2.knockV = 0;
        this.p1.walkT = 0;
        this.p2.walkT = 0;
        this.seatFighters();
      }

      startFall(n) {
        this.clearTimers();
        this.match.fall = n;
        this.match.phase = 'intro';
        this.match.time = T.round_seconds;
        this.match.roundWinner = null;
        this.p1.state = 'idle';
        this.p2.state = 'idle';
        this.p1.attack = null;
        this.p2.attack = null;
        this.p1.hitTimer = 0;
        this.p2.hitTimer = 0;
        this.p1.knockV = 0;
        this.p2.knockV = 0;
        this.p1.cd = 0;
        this.p2.cd = 0;
        this.p1.jumpY = 0;
        this.p2.jumpY = 0;
        this.p1.velY = 0;
        this.p2.velY = 0;
        this.p1.health = this.p1.max;
        this.p2.max = this.rivalMax();
        this.p2.health = this.p2.max;
        this.p1.meter = 0;
        this.p2.meter = 0;
        this.p1.finisherReady = false;
        this.p2.finisherReady = false;
        this.ai = { think: .35, attackCd: 1, guard: 0, jumpCd: .5 };
        this.playerInput = this.blankInput();
        this.aiInput = this.blankInput();
        this.combo = 0;
        this.comboT = 0;
        this.p1S && this.p1S.clearTint();
        this.p2S && this.p2S.clearTint();
        this.p1S && this.p1S.setAngle(0);
        this.p2S && this.p2S.setAngle(0);
        this.p1B && this.p1B.setAngle(0);
        this.p2B && this.p2B.setAngle(0);
        UI.health(1, 1);
        UI.health(2, 1);
        UI.heat(1, 0);
        UI.heat(2, 0);
        UI.timer(T.round_seconds);
        UI.combo(0);
        UI.fall(n);
        UI.pips(this.match.wins[0], this.match.wins[1]);
        this.resetRoundPositions();
        this.seatFighters();
        this.syncSpritePositions();
        this.setFaces();
        UI.clearStamp();
        if (n === 1) {
          UI.stamp('FALL 1', { hold: 900, tone: 'small cream', sound: 'stamp_thud' });
        } else {
          UI.stamp('FALL ' + n, { hold: 900, tone: 'small cream', sound: 'stamp_thud' });
        }
        this.later(1000, () => {
          UI.stamp('BELL!', { hold: 700, tone: 'red', sound: 'bell' });
          this.later(720, () => {
            if (!this.match.active) return;
            this.match.phase = 'fight';
            UI.clearStamp();
            if (typeof this.match.onBell === 'function') {
              const fn = this.match.onBell;
              this.match.onBell = null;
              fn();
            }
            this.match.bellRung = true;
          });
        });
      }

      finishFall(reason, winner) {
        if (this.match.phase === 'fallEnd' || this.match.phase === 'matchEnd') return;
        this.match.phase = 'fallEnd';
        this.match.reason = reason;
        this.match.roundWinner = winner;
        if (winner === 'p1') this.match.wins[0]++;
        else if (winner === 'p2') this.match.wins[1]++;
        UI.pips(this.match.wins[0], this.match.wins[1]);
        if (winner === 'p1') {
          try { MB()?.event?.('fall_won', { fall: this.match.fall }); } catch (e) { /* optional */ }
        }
        if (reason === 'pin') {
          UI.stamp('PINFALL!', { hold: 1500, tone: 'red' });
          this.flashScreen(.5);
          this.shake(.016);
        } else {
          UI.stamp('TIME!', { hold: 1500, tone: 'cream', sound: 'stamp_thud' });
          this.flashScreen(.28);
        }
        if (!winner) UI.stamp('DRAW', { hold: 1500, tone: 'cream', sound: 'stamp_thud' });
        const winnerKey = winner === 'p1' ? this.playerKey : (winner === 'p2' ? this.opponentKey : null);
        if (winnerKey) {
          UI.commentary(ROSTER[winnerKey].name + ' TAKES FALL ' + this.match.fall + '!');
        } else {
          UI.commentary('BOTH FIGHTERS ARE STILL STANDING. THIS ONE GOES ON!');
        }
        this.later(1800, () => {
          if (!this.match.active) return;
          if (this.match.wins[0] >= 2 || this.match.wins[1] >= 2) {
            this.endMatch();
          } else {
            this.startFall(this.match.fall + (winner ? 1 : 0));
          }
        });
      }

      endMatch() {
        if (this.match.phase === 'matchEnd') return;
        this.match.phase = 'matchEnd';
        const won = this.match.wins[0] > this.match.wins[1];
        if (won) {
          UI.stamp('WINNER', { hold: 2000, tone: '', sound: 'ko_roar' });
        } else {
          UI.stamp('DEFEAT', { hold: 2000, tone: 'red', sound: 'stamp_thud' });
        }
        if (typeof this.match.onEnd === 'function') {
          const fn = this.match.onEnd;
          this.match.onEnd = null;
          fn({
            won,
            seconds: this.match.seconds,
            wins: this.match.wins.slice(),
            player: this.playerKey,
            opponent: this.opponentKey,
            venue: this.venueKey,
            reason: this.match.reason || 'pin',
            finisherUsed: this.match.finisherUsed
          });
        }
      }

      beginPin(winner, loser) {
        if (this.match.phase !== 'fight') return;
        this.match.phase = 'pin';
        this.match.roundWinner = winner;
        loser.state = 'down';
        loser.attack = null;
        loser.hitTimer = 0;
        loser.knockV = 0;
        this.playerInput = this.blankInput();
        this.aiInput = this.blankInput();
        UI.commentary('THE REFEREE DROPS TO THE MAT!');
        this.flashScreen(.34);
        this.later(120, () => {
          if (!this.match.active) return;
          UI.stamp('1', { hold: 560, tone: 'cream', sound: 'pin_slap', silent: true });
          this.sfx('pin_slap', { vol: .95 });
        });
        this.later(760, () => {
          if (!this.match.active) return;
          UI.stamp('2', { hold: 560, tone: 'cream', sound: 'pin_slap', silent: true });
          this.sfx('pin_slap', { vol: .95 });
        });
        this.later(1400, () => {
          if (!this.match.active) return;
          UI.stamp('3', { hold: 760, tone: 'red', sound: 'pin_slap', silent: true });
          this.sfx('pin_slap', { vol: 1 });
          this.sfx('ko_roar', { vol: .65 });
          this.shake(.012);
        });
        this.later(2250, () => {
          if (!this.match.active) return;
          this.finishFall('pin', winner);
        });
      }

      timeUp() {
        if (this.match.phase !== 'fight') return;
        let winner = null;
        if (this.p1.health > this.p2.health) winner = 'p1';
        else if (this.p2.health > this.p1.health) winner = 'p2';
        this.finishFall('time', winner);
      }

      hold(act, down) {
        if (act === 'left' || act === 'right' || act === 'guard') this.playerInput[act] = down;
      }

      press(act) {
        if (act === 'jump' || act === 'quick' || act === 'power' || act === 'kick') this.playerInput[act] = true;
      }

      releaseAll() { this.playerInput = this.blankInput(); }

      hitstop(seconds) { this.stop = Math.max(this.stop, seconds); }

      shake(power) { this.cameras.main.shake(120, power); }

      jolt() { /* the stage shake is handled by the camera */ }

      sfx(name, opts) { if (window.__audio) window.__audio.play(name, opts || {}); }

      flashScreen(alpha) {
        this.flash.setAlpha(Math.max(this.flash.alpha, alpha));
      }

      burst(x, y, color, count, power) {
        const u = this.unit;
        for (let i = 0; i < count; i++) {
          const a = rnd(0, Math.PI * 2);
          const sp = rnd(30, 260) * power * u;
          this.particles.push({
            x, y,
            vx: Math.cos(a) * sp,
            vy: Math.sin(a) * sp - rnd(20, 120) * u,
            life: 0,
            max: rnd(.28, .72),
            size: rnd(1.5, 5.5) * u,
            color
          });
        }
        if (this.particles.length > 260) this.particles.splice(0, this.particles.length - 260);
      }

      wave(x, y, color, power) {
        this.waves.push({ x, y, r: 4 * this.unit, rMax: 130 * this.unit * power, life: 0, max: .38, color });
      }

      damageText(x, y, amount, mine) {
        const t = this.add.text(x, y, String(amount), {
          fontFamily: '"Alfa Slab One", Georgia, serif',
          fontSize: Math.round(26 * this.unit) + 'px',
          color: mine ? '#f5b731' : '#ff6b4a',
          stroke: '#100804',
          strokeThickness: Math.max(2, Math.round(4 * this.unit))
        }).setOrigin(.5, 1).setDepth(5).setAngle(rnd(-8, 8));
        this.tweens.add({
          targets: t,
          y: y - 52 * this.unit,
          alpha: 0,
          duration: 740,
          ease: 'Cubic.easeOut',
          onComplete: () => t.destroy()
        });
      }

      addCombo() {
        this.combo++;
        this.comboT = 1.35;
        UI.combo(this.combo);
      }

      resetCombo() {
        if (this.combo >= 2) UI.combo(0);
        this.combo = 0;
        this.comboT = 0;
      }

      canAct(f) {
        return f.state === 'idle' || f.state === 'walk' || f.state === 'guard';
      }

      startAttack(f, type) {
        const r = ROSTER[f.key];
        const mv = r.moves[type];
        if (!mv) return;
        f.state = 'attack';
        f.attack = {
          type,
          t: 0,
          windup: mv.windup,
          active: mv.active,
          recover: mv.recover,
          range: mv.range,
          damage: mv.damage,
          hitstun: mv.hitstun,
          knockback: mv.knockback,
          gain: mv.gain,
          lunge: mv.lunge || 0,
          hit: false,
          phase: 'windup'
        };
        f.cd = mv.cooldown;
        if (type === 'finisher') {
          f.meter = 0;
          f.finisherReady = false;
          UI.heat(f === this.p1 ? 1 : 2, 0);
          UI.finisher(r.movesName.finisher);
          UI.commentary(r.finisherLine);
          this.wave(f.x + f.facing * 40 * this.unit, this.groundY - 110 * this.unit, r.accentNum, 1.9);
          this.shake(.008);
          this.sfx('super_bass', { vol: .9 });
          this.match.finisherUsed++;
          try { MB()?.event?.('finisher', { move: r.key }); } catch (e) { /* optional */ }
        }
      }

      updateAttack(f, dt) {
        const a = f.attack;
        if (!a) { f.state = 'idle'; return; }
        f.cd = Math.max(0, f.cd - dt);
        a.t += dt;
        if (a.t < a.windup) {
          a.phase = 'windup';
        } else if (a.t < a.windup + a.active) {
          if (a.phase !== 'active') {
            a.phase = 'active';
            if (a.lunge) {
              const target = f === this.p1 ? this.p2 : this.p1;
              if (target.state !== 'down') f.x += f.facing * a.lunge * this.unit;
            }
            this.sfx(a.type === 'finisher' ? 'super_bass' : 'whoosh', { vol: a.type === 'finisher' ? .8 : .55 });
          }
          this.checkHit(f);
        } else if (a.t < a.windup + a.active + a.recover) {
          a.phase = 'recover';
        } else {
          f.attack = null;
          f.state = 'idle';
        }
      }

      checkHit(f) {
        const a = f.attack;
        if (!a || a.hit) return;
        const target = f === this.p1 ? this.p2 : this.p1;
        if (target.state === 'down') return;
        if (target.jumpY > 42 * this.unit) return;
        const dx = target.x - f.x;
        if (dx * f.facing <= 0 && Math.abs(dx) > 8) return;
        const reach = (a.range + (f === this.p1 ? 18 : 12)) * this.unit;
        const hurt = (a.type === 'finisher' ? 34 : 26) * this.unit;
        if (Math.abs(dx) > reach + hurt) return;
        a.hit = true;
        this.landHit(f, target, a);
      }

      landHit(attacker, defender, a) {
        const u = this.unit;
        const ar = ROSTER[attacker.key];
        const contactX = (attacker.x + defender.x) / 2 + attacker.facing * 12 * u;
        const contactY = this.groundY - ROSTER[defender.key].heightScale * 240 * u - defender.jumpY;
        const blocking = defender.state === 'guard' && defender.jumpY <= 0;
        let dmg = a.damage;

        if (blocking) {
          dmg = Math.max(1, Math.round(a.damage * .16));
          defender.health = Math.max(0, defender.health - dmg);
          defender.meter = Math.min(100, defender.meter + 7);
          attacker.meter = Math.min(100, attacker.meter + 3);
          defender.knockV = -attacker.facing * 150 * u;
          this.sfx('block_clank', { vol: .6 });
          this.burst(contactX, contactY, 0x28b8ae, 11, .6);
          this.wave(contactX, contactY, 0x28b8ae, .55);
          this.hitstop(Math.max(.03, T.impact_stop * .55));
          this.shake(.004);
          this.damageText(contactX + 10 * u, contactY - 12 * u, dmg, attacker === this.p1);
          UI.commentary('BLOCKED! NO ROOM TO BREATHE!');
        } else {
          defender.health = Math.max(0, defender.health - dmg);
          defender.meter = Math.min(100, defender.meter + 8);
          attacker.meter = Math.min(100, attacker.meter + a.gain);
          defender.state = 'hit';
          defender.hitTimer = a.hitstun;
          defender.attack = null;
          defender.knockV = -attacker.facing * a.knockback * u * 6.4;
          this.sfx(a.type === 'finisher' ? 'finisher_hit' : 'hit_punch', { vol: a.type === 'finisher' ? 1 : .82 });
          this.burst(contactX, contactY, ar.accentNum, 12 + Math.round(dmg), a.type === 'finisher' ? 1.6 : .9);
          if (a.type === 'finisher') {
            this.wave(contactX, contactY, 0xffe9a3, 1.7);
            this.wave(contactX, contactY, ar.accentNum, 1.2);
            this.flashScreen(.55);
            this.shake(.018);
            this.hitstop(T.impact_stop * 2.5);
            UI.commentary(ar.finisherLine);
          } else if (a.type === 'power' || a.type === 'kick') {
            this.wave(contactX, contactY, ar.accentNum, .95);
            this.flashScreen(.34);
            this.shake(.011);
            this.hitstop(T.impact_stop);
            UI.commentary(a.type === 'power' ? 'WHAT A SHOT! THAT ONE SHOOK THE BUILDING!' : 'A DROPKICK OUT OF NOWHERE!');
          } else {
            this.wave(contactX, contactY, ar.accentNum, .6);
            this.flashScreen(.22);
            this.shake(.006);
            this.hitstop(T.impact_stop * .65);
          }
          this.damageText(contactX, contactY, dmg, attacker === this.p1);
          if (attacker === this.p1) this.addCombo();
          else this.resetCombo();
          this.flashFighter(defender);
          this.recoil(defender, attacker, a);
        }

        if (attacker === this.p2) {
          this.ai.attackCd = Math.max(this.ai.attackCd, rnd(.55, .95));
          this.ai.think = Math.max(this.ai.think, .3);
        }
        if (defender === this.p2) {
          this.ai.attackCd = Math.max(this.ai.attackCd, .14 + a.hitstun * .55);
          this.ai.think = Math.max(this.ai.think, .2);
          this.ai.guard = 0;
        }

        UI.health(1, this.p1.health / this.p1.max);
        UI.health(2, this.p2.health / this.p2.max);
        UI.heat(1, this.p1.meter / 100);
        UI.heat(2, this.p2.meter / 100);
        if (this.p1.meter >= 100 && !this.p1.finisherReady && this.match.phase === 'fight') {
          this.p1.finisherReady = true;
          UI.commentary(ROSTER[this.playerKey].movesName.finisher + ' IS READY! PRESS POWER!');
        }

        if (defender.health <= 0) {
          defender.state = 'down';
          defender.attack = null;
          defender.hitTimer = 0;
          defender.knockV = -attacker.facing * 70 * u;
          this.beginPin(attacker === this.p1 ? 'p1' : 'p2', defender);
        }
      }

      flashFighter(f) {
        const spr = f === this.p1 ? this.p1S : this.p2S;
        spr.setTint(0xffffff);
        this.later(80, () => { if (spr && spr.active) spr.clearTint(); });
      }

      recoil(f, attacker, a) {
        const front = f === this.p1 ? this.p1S : this.p2S;
        const back = f === this.p1 ? this.p1B : this.p2B;
        const tilt = attacker.facing * (a.type === 'finisher' ? 11 : (a.type === 'power' ? 8 : (a.type === 'kick' ? 9 : 5)));
        this.tweens.killTweensOf([front, back]);
        front.setAngle(tilt);
        back.setAngle(tilt);
        this.tweens.add({
          targets: [front, back],
          angle: 0,
          duration: a.type === 'finisher' ? 320 : (a.type === 'kick' ? 240 : 210),
          ease: 'Back.easeOut'
        });
      }

      updateFighter(f, input, dt) {
        const other = f === this.p1 ? this.p2 : this.p1;
        f.cd = Math.max(0, f.cd - dt);
        if (f.state === 'down') {
          f.knockV *= Math.pow(.0008, dt);
          f.x += f.knockV * dt;
          return;
        }
        if (f.hitTimer > 0) {
          f.hitTimer -= dt;
          f.x += f.knockV * dt;
          f.knockV *= Math.pow(.0025, dt);
          if (f.hitTimer <= 0 && f.state === 'hit') {
            f.state = 'idle';
            f.knockV = 0;
          }
          return;
        }
        if (f.state === 'attack') {
          this.updateAttack(f, dt);
          return;
        }
        if (f.state === 'jump') {
          f.jumpY += f.velY * dt;
          f.velY -= 2350 * this.unit * dt;
          const rr = ROSTER[f.key];
          const airSpeed = 300 * rr.speedMult * .68 * this.unit * (f === this.p2 ? T.rival_speed : 1);
          if (input.left) f.x -= airSpeed * dt;
          if (input.right) f.x += airSpeed * dt;
          f.facing = other.x >= f.x ? 1 : -1;
          if (f.jumpY <= 0) {
            f.jumpY = 0;
            f.velY = 0;
            f.state = 'idle';
            this.burst(f.x, this.groundY, 0x8a9199, 5, .35);
          }
          return;
        }

        const can = this.canAct(f);
        f.facing = other.x >= f.x ? 1 : -1;
        const rr = ROSTER[f.key];

        if (can && input.power) {
          input.power = false;
          if (f.cd <= 0) {
            this.startAttack(f, f.meter >= 100 ? 'finisher' : 'power');
            return;
          }
        }
        if (can && input.quick) {
          input.quick = false;
          if (f.cd <= 0) {
            this.startAttack(f, 'quick');
            return;
          }
        }
        if (can && input.kick) {
          input.kick = false;
          if (f.cd <= 0) {
            this.startAttack(f, 'kick');
            return;
          }
        }
        input.power = false;
        input.quick = false;
        input.kick = false;

        if (can && input.jump) {
          input.jump = false;
          f.state = 'jump';
          f.jumpY = .5;
          f.velY = 720 * this.unit;
          this.burst(f.x, this.groundY, 0x8a9199, 4, .3);
          return;
        }
        input.jump = false;

        if (can && input.guard) {
          f.state = 'guard';
          return;
        }

        let moving = 0;
        if (input.left) moving -= 1;
        if (input.right) moving += 1;
        if (can && moving !== 0) {
          f.state = 'walk';
          f.walkT += dt;
          f.x += moving * 300 * rr.speedMult * this.unit * (f === this.p2 ? T.rival_speed : 1) * dt;
          if (Math.random() < dt * 7) {
            this.particles.push({
              x: f.x - moving * 18 * this.unit,
              y: this.groundY - 2 * this.unit + rnd(-2, 2),
              vx: -moving * rnd(10, 50) * this.unit,
              vy: rnd(-35, -10) * this.unit,
              life: 0,
              max: rnd(.2, .45),
              size: rnd(1, 2.6) * this.unit,
              color: 0x8a9199
            });
          }
        } else if (can) {
          f.state = 'idle';
        }
      }

      updateAI(dt) {
        const f = this.p2;
        const t = this.p1;
        if (f.state === 'down' || this.match.phase !== 'fight') return;
        const profile = ROSTER[f.key].ai;
        this.ai.think -= dt;
        this.ai.attackCd = Math.max(0, this.ai.attackCd - dt);
        this.ai.jumpCd = Math.max(0, this.ai.jumpCd - dt);
        const gap = Math.abs(t.x - f.x);
        const toward = t.x < f.x ? 'left' : 'right';
        const away = toward === 'left' ? 'right' : 'left';
        this.aiInput.left = false;
        this.aiInput.right = false;
        this.aiInput.guard = false;

        if (this.ai.guard > 0) {
          this.ai.guard -= dt;
          this.aiInput.guard = true;
          return;
        }

        const rr = ROSTER[f.key];
        const heavyReach = rr.moves.power.range * this.unit;
        const lightReach = rr.moves.quick.range * this.unit;

        if (this.ai.think <= 0) {
          this.ai.think = rnd(.16, .30);

          if (t.state === 'attack' && t.attack && gap < heavyReach + 20 * this.unit) {
            if (Math.random() < profile.guard) {
              this.ai.guard = rnd(.24, .44);
              return;
            }
            if (Math.random() < profile.jump && this.ai.jumpCd <= 0) {
              this.aiInput.jump = true;
              this.ai.jumpCd = 1.1;
              return;
            }
          }

          if (gap > heavyReach * .9) {
            if (toward === 'left') this.aiInput.left = true;
            else this.aiInput.right = true;
            if (gap > heavyReach * 1.6 && Math.random() < .08 + profile.jump * .2 && this.ai.jumpCd <= 0) {
              this.aiInput.jump = true;
              this.ai.jumpCd = 1.4;
            }
          } else if (gap < 72 * this.unit) {
            if (Math.random() < profile.retreat) {
              if (away === 'left') this.aiInput.left = true;
              else this.aiInput.right = true;
            }
          }

          const unsafe = t.state === 'hit' || t.state === 'down' || t.state === 'jump';
          if (!unsafe && gap <= heavyReach && this.ai.attackCd <= 0 && Math.random() < profile.aggression) {
            if (f.meter >= 100 && Math.random() < .5) {
              this.aiInput.power = true;
              this.ai.attackCd = rnd(1.2, 1.7);
            } else if (Math.random() < .30) {
              this.aiInput.power = true;
              this.ai.attackCd = rnd(1.0, 1.5);
            } else if (profile.prefer === 'kick' && Math.random() < .5) {
              this.aiInput.kick = true;
              this.ai.attackCd = rnd(.7, 1.05);
            } else {
              this.aiInput.quick = true;
              this.ai.attackCd = rnd(.64, .98);
            }
          }
          void lightReach;
        }
      }

      syncSpritePositions() {
        if (!this.p1S || !this.p2S) return;
        this.p1S.x = this.p1.x;
        this.p1S.y = this.groundY - this.p1.jumpY + this.idleBob(this.p1);
        this.p2S.x = this.p2.x;
        this.p2S.y = this.groundY - this.p2.jumpY + this.idleBob(this.p2);
        this.p1B.x = this.p1.x + this.p1.facing * 3 * this.unit;
        this.p1B.y = this.p1S.y;
        this.p2B.x = this.p2.x + this.p2.facing * 3 * this.unit;
        this.p2B.y = this.p2S.y;
      }

      idleBob(f) {
        if (f.state === 'attack' || f.state === 'down' || f.state === 'hit' || f.jumpY > 0) return 0;
        const speed = f.state === 'walk' ? 9 : 3.4;
        const amp = f.state === 'walk' ? 2.4 : 1.6;
        return Math.sin(f.idleT * speed) * amp * this.unit;
      }

      setFaces() {
        const apply = (f, spr, back) => {
          const r = ROSTER[f.key];
          const flip = f.state === 'down' ? false : f.facing === -1;
          const angle = f.state === 'walk'
            ? (f.facing * -2.4 + Math.sin(f.walkT * 12) * 2.2)
            : (f.state === 'guard' ? f.facing * 2 : Math.sin(f.idleT * 1.7) * .8);
          spr.setFlipX(flip);
          back.setFlipX(flip);
          if (f.state === 'attack') {
            const a = f.attack;
            const tilt = a && a.phase === 'active' ? f.facing * (a.type === 'finisher' ? 5 : 3) : 0;
            spr.setAngle(tilt);
            back.setAngle(tilt);
          } else if (f.state !== 'hit') {
            spr.setAngle(angle);
            back.setAngle(angle);
          }
          void r;
        };
        apply(this.p1, this.p1S, this.p1B);
        apply(this.p2, this.p2S, this.p2B);
      }

      updateSprites(dt) {
        const apply = (f, spr, back) => {
          const r = ROSTER[f.key];
          let tex = f.key + '_idle';
          if (f.state === 'walk') {
            tex = f.key + '_idle';
          } else if (f.state === 'guard') {
            tex = f.key + '_idle';
          } else if (f.state === 'hit') {
            tex = f.key + '_idle';
          } else if (f.state === 'down') {
            tex = f.key + '_down';
          } else if (f.state === 'attack' && f.attack) {
            tex = f.attack.phase === 'windup' ? f.key + '_idle' : (f.attack.type === 'kick' ? f.key + '_kick' : f.key + '_strike');
          } else if (f.state === 'jump') {
            tex = f.key + '_strike';
          }
          if (spr.texture.key !== tex) spr.setTexture(tex);
          if (back.texture.key !== tex) back.setTexture(tex);
          if (f.state === 'down') {
            spr.setAngle(0);
            back.setAngle(0);
          }
          if (f.state === 'guard') {
            spr.setTint(0xdfe9ff);
          } else if (f.state !== 'hit') {
            spr.clearTint();
          }
          void r;
        };
        apply(this.p1, this.p1S, this.p1B);
        apply(this.p2, this.p2S, this.p2B);
        this.setFaces();
        this.syncSpritePositions();
      }

      updateParticles(dt) {
        const fx = this.fx;
        fx.clear();
        const u = this.unit;

        this.particles.forEach((p) => { p.life += dt; });
        this.particles = this.particles.filter((p) => p.life < p.max);
        for (const p of this.particles) {
          p.vy += 980 * u * dt;
          p.x += p.vx * dt;
          p.y += p.vy * dt;
          const a = 1 - p.life / p.max;
          fx.fillStyle(p.color, a * .95);
          fx.fillCircle(p.x, p.y, Math.max(.6, p.size * (.4 + a * .8)));
        }

        this.waves.forEach((w) => { w.life += dt; });
        this.waves = this.waves.filter((w) => w.life < w.max);
        for (const w of this.waves) {
          const t = w.life / w.max;
          const rad = w.r + (w.rMax - w.r) * t;
          fx.lineStyle(Math.max(1.5, 6 * u * (1 - t)), w.color, (1 - t) * .9);
          fx.strokeCircle(w.x, w.y, rad);
        }

        if (this.p1) {
          const c1 = ROSTER[this.p1.key].accentNum;
          fx.fillStyle(c1, .055);
          fx.fillEllipse(this.p1.x, this.groundY - 4 * u, 118 * u, 20 * u);
        }
        if (this.p2) {
          const c2 = ROSTER[this.p2.key].accentNum;
          fx.fillStyle(c2, .055);
          fx.fillEllipse(this.p2.x, this.groundY - 4 * u, 118 * u, 20 * u);
        }

        const shadow = (f) => {
          const lift = clamp(1 - f.jumpY / (110 * u), .3, 1);
          fx.fillStyle(0x080402, .34 * lift);
          fx.fillEllipse(f.x, this.groundY + 1.5 * u, 100 * u * lift, 12 * u * lift);
        };
        shadow(this.p1);
        shadow(this.p2);

        if (this.p1 && this.p1.state === 'guard') this.drawGuard(this.p1);
        if (this.p2 && this.p2.state === 'guard') this.drawGuard(this.p2);

        if (this.flash.alpha > 0) this.flash.setAlpha(Math.max(0, this.flash.alpha - dt * 5.5));
      }

      drawGuard(f) {
        const fx = this.fx;
        const u = this.unit;
        const x = f.x + f.facing * 34 * u;
        const y = this.groundY - 76 * u;
        fx.lineStyle(Math.max(2, 6 * u), 0xdfe9ff, .75);
        fx.beginPath();
        fx.arc(x, y, 50 * u, -1.15, 1.15, false);
        fx.strokePath();
        fx.lineStyle(Math.max(1, 2 * u), 0x100804, .8);
        fx.beginPath();
        fx.arc(x, y, 54 * u, -1.05, 1.05, false);
        fx.strokePath();
      }

      updateWeather(dt) {
        this.ambientT += dt;
        const g = this.weather;
        g.clear();
        const u = this.unit;
        if (this.venueKey === 'parking') {
          for (const r of this.rain) {
            r.y += r.sp * dt;
            r.x -= r.sp * .18 * dt;
            if (r.y > this.H + 20) { r.y = -20; r.x = rnd(-this.W * .2, this.W * 1.2); }
            g.lineStyle(Math.max(.6, 1.1 * u), 0xb9e7e4, r.a);
            g.lineBetween(r.x, r.y, r.x - r.len * .25, r.y + r.len);
          }
          if (Math.random() < dt * .12) {
            g.fillStyle(0xfff6d4, .05);
            g.fillRect(0, 0, this.W, this.H);
          }
        } else {
          for (const m of this.motes) {
            m.x += m.vx * dt;
            m.y += m.vy * dt;
            if (m.y < -10) { m.y = this.H + 10; m.x = rnd(0, this.W); }
            if (m.x < -10) m.x = this.W + 10;
            if (m.x > this.W + 10) m.x = -10;
            g.fillStyle(this.venueKey === 'locker' ? 0xdff7ff : 0xffe9a3, m.a);
            g.fillCircle(m.x, m.y, m.r);
          }
          if (this.venueKey === 'locker' && Math.random() < dt * 2.2) {
            this.particles.push({
              x: rnd(this.W * .1, this.W * .9),
              y: this.groundY + 2 * u,
              vx: rnd(-14, 14) * u,
              vy: rnd(-46, -18) * u,
              life: 0,
              max: rnd(.9, 1.8),
              size: rnd(4, 10) * u,
              color: 0xdff7ff
            });
          }
        }
      }

      update(time, delta) {
        if (!this.match) return;
        const dt = Math.min(delta / 1000, 1 / 30);
        this.idleClock += dt;
        if (this.p1) this.p1.idleT += dt;
        if (this.p2) this.p2.idleT += dt;

        if (!this.match.active) {
          this.updateParticles(dt);
          this.updateWeather(dt);
          if (this.match.phase === 'idle') {
            if (this.p1S) { this.p1S.setVisible(false); }
            if (this.p2S) { this.p2S.setVisible(false); }
          }
          return;
        }

        if (this.stop > 0) {
          this.stop -= dt;
          this.updateParticles(dt);
          this.updateWeather(dt);
          return;
        }

        if (this.match.bellRung && this.match.phase !== 'matchEnd') this.match.seconds += dt;

        if (this.match.phase === 'fight') {
          this.match.time -= dt;
          if (this.match.time <= 0) {
            this.match.time = 0;
            this.timeUp();
          }
          UI.timer(this.match.time);
          this.updateAI(dt);
          this.updateFighter(this.p1, this.playerInput, dt);
          this.updateFighter(this.p2, this.aiInput, dt);
          this.keepApart();
          this.comboT -= dt;
          if (this.comboT <= 0 && this.combo > 0) this.resetCombo();
          UI.health(1, this.p1.health / this.p1.max);
          UI.health(2, this.p2.health / this.p2.max);
          UI.heat(1, this.p1.meter / 100);
          UI.heat(2, this.p2.meter / 100);
          this.commentaryT -= dt;
          if (this.commentaryT <= 0 && this.match.seconds > 4) {
            this.commentaryT = rnd(7, 11);
            UI.commentary(COMMENTARY[Math.floor(Math.random() * COMMENTARY.length)]);
          }
        }

        this.updateParticles(dt);
        this.updateWeather(dt);
        this.updateSprites(dt);
      }

      keepApart() {
        const minGap = 145 * this.unit;
        this.p1.x = clamp(this.p1.x, this.W * .12, this.W * .88);
        this.p2.x = clamp(this.p2.x, this.W * .12, this.W * .88);
        if (this.p2.x - this.p1.x < minGap) {
          const left = this.p1.x < this.p2.x;
          const mid = (this.p1.x + this.p2.x) / 2;
          if (this.p1.state === 'down' || this.p2.state === 'down') {
            if (left) this.p2.x = Math.min(this.W * .88, mid + minGap / 2);
            else this.p1.x = Math.max(this.W * .12, mid - minGap / 2);
          } else {
            this.p1.x = mid - minGap / 2;
            this.p2.x = mid + minGap / 2;
          }
        }
        this.p1.x = clamp(this.p1.x, this.W * .12, this.W * .88);
        this.p2.x = clamp(this.p2.x, this.W * .12, this.W * .88);
      }
    }

    return FightScene;
  }

  document.addEventListener('scene-ready', () => {
    S.sceneReady = true;
    UI.loading(false);
    const scene = window.__scene;
    if (scene && typeof scene.applyTune === 'function') scene.applyTune(T);
    if (S.afterReady && scene && typeof scene.beginMatch === 'function') {
      const config = S.afterReady;
      S.afterReady = null;
      scene.beginMatch(config);
    }
  });

  function boot() {
    buildRoster();
    selectFighter(S.pick);
    buildVenues();
    updateMatchSummary();
    selectOpponent(S.opponent);
    syncAllPicks();
    updateRecordLine();
    wireControls();
    UI.setScreen('roster');
    loadTune();
    const waitForSdk = (tries = 0) => {
      if (MB()) { setupSdk(); return; }
      if (tries < 25) setTimeout(() => waitForSdk(tries + 1), 200);
    };
    waitForSdk();
  }

  boot();
})();
